import { supabase } from '../../lib/supabase'

export async function getServerSideProps({ params }) {
  const { data } = await supabase.from('products').select('*').eq('id', params.id).single()
  return { props: { product: data } }
}

export default function ProductPage({ product }) {
  return (
    <div className="p-6 max-w-xl mx-auto">
      <img src={product.image_url} className="w-full h-60 object-cover rounded-xl" />
      <h1 className="text-2xl font-bold mt-4">{product.title}</h1>
      <p className="mt-2">{product.description}</p>
      <p className="text-green-600 font-bold text-xl mt-2">{product.price} أوقية</p>
      <a
        href={`https://wa.me/22246420789?text=أريد طلب ${product.title}`}
        target="_blank"
        className="inline-block mt-4 bg-green-600 text-white px-4 py-2 rounded"
      >
        اطلب عبر واتساب
      </a>
    </div>
  )
}