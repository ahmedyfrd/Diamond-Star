import { supabase } from '../lib/supabase'
import Link from 'next/link'

export async function getServerSideProps() {
  const { data: products } = await supabase.from('products').select('*')
  return { props: { products } }
}

export default function Home({ products }) {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4 text-center">🌟 Diamond Star</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {products.map((p) => (
          <div key={p.id} className="border rounded-xl p-4 shadow">
            <img src={p.image_url} className="w-full h-40 object-cover mb-2" />
            <h2 className="text-xl font-semibold">{p.title}</h2>
            <p>{p.description}</p>
            <p className="text-green-700 font-bold">{p.price} أوقية</p>
            <Link href={`/product/${p.id}`}>
              <button className="mt-2 bg-blue-500 text-white px-4 py-1 rounded">عرض التفاصيل</button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}